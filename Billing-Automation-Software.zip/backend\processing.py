import os
import pdfplumber
import logging
from pymongo import MongoClient

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# MongoDB Connection
# Using default localhost for now. Update URI if needed.
MONGO_URI = "mongodb://localhost:27017/"
DB_NAME = "billbot_db"
COLLECTION_NAME = "bills"

try:
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    collection = db[COLLECTION_NAME]
    logger.info("Connected to MongoDB.")
except Exception as e:
    logger.error(f"Failed to connect to MongoDB: {e}")
    client = None
    db = None
    collection = None

def extract_data_from_pdf(pdf_path):
    """
    Extracts relevant data from a PDF bill using pdfplumber.
    """
    data = {}
    try:
        with pdfplumber.open(pdf_path) as pdf:
            text = ""
            for page in pdf.pages:
                text += page.extract_text() or ""
            
            # Simple keyword extraction logic - CUSTOMIZE based on actual bill format
            # Example: Looking for "Consumer No:", "Bill Date:", "Amount:"
            import re
            lines = text.split('\n')
            
            # Common Maharashtra areas to look for if BU Name isn't clear
            areas_to_scan = ["Nagpur", "Yavatmal", "Pune", "Mumbai", "Nashik", "Aurangabad", "Amravati", "Thane", "Solapur", "Jalgaon"]
            
            for line in lines:
                # Extract Consumer Number
                if "Consumer No" in line:
                    parts = re.split(r'[:\s]+', line)
                    for i, p in enumerate(parts):
                        if "Consumer" in p and i+2 < len(parts):
                            data["consumer_number"] = parts[i+2].strip()
                            break
                    if not data.get("consumer_number"):
                        data["consumer_number"] = line.split(":")[-1].strip()

                # Extract Bill Month/Date
                month_match = re.search(r"(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)[\s-]*\d{2,4}", line, re.IGNORECASE)
                if month_match:
                    data["bill_month"] = month_match.group(0).upper()

                if "Bill Date" in line:
                    data["bill_date"] = line.split(":")[-1].strip()

                # Extract Amount
                if "Total Amount" in line or "Net Amount" in line:
                    amt_match = re.search(r"([\d,]+\.\d{2})", line)
                    if amt_match:
                        data["amount"] = amt_match.group(1).replace(",", "")

                # Extract Area (Look for BU Name or specific cities)
                # Be more selective to avoid disclaimers
                if ("BU Name" in line or "Circle" in line) and ":" in line:
                    val = line.split(":")[-1].strip()
                    if len(val) < 25: # Only accept if it looks like a real name, not a sentence
                        data["area"] = val
                
                for area in areas_to_scan:
                    if area.lower() in line.lower() and not data.get("area"):
                        data["area"] = area

                # Extract Export/Import
                export_match = re.search(r"Export\s*[:\-]?\s*([\d\.]+)", line, re.IGNORECASE)
                if export_match:
                    data["export"] = float(export_match.group(1))
                
                import_match = re.search(r"Import\s*[:\-]?\s*([\d\.]+)", line, re.IGNORECASE)
                if import_match:
                    data["import"] = float(import_match.group(1))
            
            # Default values if not found
            if not data.get("area"): data["area"] = "Other"
            if not data.get("bill_month"): data["bill_month"] = "Unknown"
            
            data["filename"] = os.path.basename(pdf_path)
            data["processed_at"] = os.path.getmtime(pdf_path)
            
            return data
    except Exception as e:
        logger.error(f"Error extracting data from {pdf_path}: {e}")
        return None

def process_downloads(download_dir="downloads"):
    """
    Iterates through downloaded PDFs, extracts data, and saves to MongoDB.
    """
    processed_count = 0
    if not os.path.exists(download_dir):
        logger.warning(f"Download directory {download_dir} does not exist.")
        return 0

    for filename in os.listdir(download_dir):
        if filename.lower().endswith(".pdf"):
            file_path = os.path.join(download_dir, filename)
            extracted_data = extract_data_from_pdf(file_path)
            
            if extracted_data and collection is not None:
                # Upsert based on consumer number or filename to avoid duplicates
                query = {"filename": filename} 
                collection.update_one(query, {"$set": extracted_data}, upsert=True)
                processed_count += 1
    
    logger.info(f"Processed {processed_count} PDF files.")
    return processed_count

def get_all_bills():
    """Retrieves all bill records from MongoDB."""
    if collection is None:
        return []
    return list(collection.find({}, {"_id": 0})) # Exclude _id specifically

def get_dashboard_stats():
    """Calculates real stats for the dashboard."""
    if collection is None:
        return {
            "totalConsumers": 0,
            "totalBills": 0,
            "energySaved": "0 kWh",
            "pendingCount": 0,
            "totalAmount": 0,
            "areaDistribution": [],
            "recentBills": []
        }
    
    total_bills = collection.count_documents({})
    unique_consumers_list = collection.distinct("consumer_number")
    unique_consumers = len(unique_consumers_list)
    
    # Calculate total amount and energy saved
    total_amount = 0
    total_export = 0
    total_import = 0
    area_map = {}
    
    all_bills = list(collection.find({}, {"amount": 1, "consumer_number": 1, "filename": 1, "processed_at": 1, "export": 1, "import": 1, "area": 1, "bill_month": 1}))
    for b in all_bills:
        try:
            amt_str = str(b.get("amount", "0")).replace(",", "")
            total_amount += float(amt_str)
            total_export += float(b.get("export", 0))
            total_import += float(b.get("import", 0))
            
            # Real Area Distribution from extracted data
            area_name = b.get("area", "Other")
            # Cleaning step: If area name is way too long, it's probably a mistake in extraction
            if len(area_name) > 20: 
                area_name = area_name[:20] + "..."
            elif "E-mail" in area_name or "Circle office" in area_name:
                area_name = "Other"
                
            area_map[area_name] = area_map.get(area_name, 0) + 1
        except:
            pass
    
    energy_saved_val = max(0, total_export - total_import)
    energy_saved_str = f"{round(energy_saved_val / 1000, 2)} MWh" if energy_saved_val > 1000 else f"{int(energy_saved_val)} kWh"
            
    area_distribution = [{"name": k, "value": v} for k, v in area_map.items()]
    
    # Get 5 Most Recent Bills
    recent_bills = sorted(all_bills, key=lambda x: x.get("processed_at", 0), reverse=True)[:5]
    recent_bills_cleaned = []
    for rb in recent_bills:
        recent_bills_cleaned.append({
            "consumer_number": rb.get("consumer_number"),
            "filename": rb.get("filename"),
            "amount": rb.get("amount"),
            "processed_at": rb.get("processed_at"),
            "area": rb.get("area", "Other"),
            "bill_month": rb.get("bill_month", "N/A")
        })

    # Daily Breakdown
    from datetime import datetime
    daily_map = {}
    for b in all_bills:
        try:
            ts = b.get("processed_at")
            if ts:
                day = datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
                daily_map[day] = daily_map.get(day, 0) + 1
        except:
            pass
    
    # Demonstration Mode: If no real data, show samples for Nagpur, Nashik, Yavatmal
    if not all_bills:
        area_distribution = [
            {"name": "Nagpur", "value": 45},
            {"name": "Nashik", "value": 32},
            {"name": "Yavatmal", "value": 18}
        ]
        total_amount = 125450.00
        total_bills = 95
        unique_consumers = 88
        energy_saved_str = "12.5 MWh"
        daily_distribution = [
            {"date": "2024-02-01", "count": 12},
            {"date": "2024-02-02", "count": 18},
            {"date": "2024-02-03", "count": 25},
            {"date": "2024-02-04", "count": 15},
            {"date": "2024-02-05", "count": 25}
        ]
        # Add sample recent bills for visual completeness
        recent_bills_cleaned = [
            {"consumer_number": "170012345678", "filename": "BILL_NAG_FEB.pdf", "amount": "1,250.00", "processed_at": 1738910000, "area": "Nagpur", "bill_month": "FEB-2024"},
            {"consumer_number": "150087654321", "filename": "BILL_NAS_FEB.pdf", "amount": "3,420.00", "processed_at": 1738908000, "area": "Nashik", "bill_month": "FEB-2024"},
            {"consumer_number": "190011223344", "filename": "BILL_YAV_FEB.pdf", "amount": "980.00", "processed_at": 1738906000, "area": "Yavatmal", "bill_month": "FEB-2024"}
        ]
    else:
        area_distribution = [{"name": k, "value": v} for k, v in area_map.items()]

    return {
        "totalConsumers": unique_consumers,
        "totalBills": total_bills,
        "energySaved": energy_saved_str, 
        "pendingCount": 0,
        "totalAmount": round(total_amount, 2),
        "areaDistribution": area_distribution,
        "recentBills": recent_bills_cleaned,
        "dailyDistribution": daily_distribution
    }
