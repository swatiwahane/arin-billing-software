// Bill calculation utility functions
// These can be easily connected to a MongoDB backend later

export interface ConsumerData {
  id: string;
  consumerNumber: string;
  name: string;
  capacity: number;
  installationDate: Date;
  panelWarranty: string;
  systemWarranty: string;
  inverterWarranty: string;
}

export interface BillInputs {
  readingDate: Date;
  generatedElectricity: number;
  exportedToGrid: number;
  importedFromGrid: number;
  billingAmount: number;
  previousBankedUnit: number;
  currentBankedUnit: number;
  systemHealth: 'Normal' | 'POOR';
  billStatus: string;
}

export interface CalculatedBillData {
  readingDate: string;
  generatedElectricity: number;
  exportedToGrid: number;
  importedFromGrid: number;
  daytimeSelfConsumption: number;
  totalConsumption: number;
  billingUnits: number;
  billingAmount: number;
  previousBankedUnit: number;
  currentBankedUnit: number;
  systemHealth: 'Normal' | 'POOR';
  billStatus: string;
  daysSinceInstallation: number;
}

export function calculateBillData(
  inputs: BillInputs,
  consumer: ConsumerData
): CalculatedBillData {
  // Formula: Daytime Self Consumption = Generated - Exported
  const daytimeSelfConsumption = inputs.generatedElectricity - inputs.exportedToGrid;

  // Formula: Total Consumption = Self Consumption + Imported
  const totalConsumption = daytimeSelfConsumption + inputs.importedFromGrid;

  // Formula: Billing Units = Total Consumption - Generated
  const billingUnits = totalConsumption - inputs.generatedElectricity;

  // Calculate days since installation
  const today = new Date();
  const installDate = new Date(consumer.installationDate);
  const daysSinceInstallation = Math.floor(
    (today.getTime() - installDate.getTime()) / (1000 * 60 * 60 * 24)
  );

  return {
    readingDate: formatDate(inputs.readingDate),
    generatedElectricity: inputs.generatedElectricity,
    exportedToGrid: inputs.exportedToGrid,
    importedFromGrid: inputs.importedFromGrid,
    daytimeSelfConsumption,
    totalConsumption,
    billingUnits,
    billingAmount: inputs.billingAmount,
    previousBankedUnit: inputs.previousBankedUnit,
    currentBankedUnit: inputs.currentBankedUnit,
    systemHealth: inputs.systemHealth,
    billStatus: inputs.billStatus,
    daysSinceInstallation,
  };
}

export function formatDate(date: Date): string {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = String(date.getFullYear()).slice(-2);
  return `${day}/${month}/${year}`;
}

export function getMonthYear(date: Date): string {
  const months = [
    'JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE',
    'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'
  ];
  return `${months[date.getMonth()]} ${date.getFullYear()}`;
}

// Mock consumer data - replace with MongoDB fetch later
export const mockConsumers: ConsumerData[] = [
  {
    id: '1',
    consumerNumber: '410098765432',
    name: 'Priya Patel Industries',
    capacity: 5,
    installationDate: new Date('2021-06-13'),
    panelWarranty: '13/06/46',
    systemWarranty: '18/06/26',
    inverterWarranty: '17/06/31',
  },
  {
    id: '2',
    consumerNumber: '410023456789',
    name: 'Rajesh Kumar Sharma',
    capacity: 5,
    installationDate: new Date('2021-06-13'),
    panelWarranty: '13/06/46',
    systemWarranty: '18/06/26',
    inverterWarranty: '17/06/31',
  },
  {
    id: '3',
    consumerNumber: '410087654321',
    name: 'SHRI DR SATISH BHASKARRAO',
    capacity: 3,
    installationDate: new Date('2021-06-13'),
    panelWarranty: '13/06/46',
    systemWarranty: '18/06/26',
    inverterWarranty: '17/06/31',
  },
  {
    id: '4',
    consumerNumber: '410012345678',
    name: 'Green Tech Solutions',
    capacity: 10,
    installationDate: new Date('2020-03-15'),
    panelWarranty: '15/03/45',
    systemWarranty: '15/03/25',
    inverterWarranty: '15/03/30',
  },
  {
    id: '5',
    consumerNumber: '410099887766',
    name: 'Solar Farms Ltd',
    capacity: 25,
    installationDate: new Date('2019-11-20'),
    panelWarranty: '20/11/44',
    systemWarranty: '20/11/24',
    inverterWarranty: '20/11/29',
  },
];
