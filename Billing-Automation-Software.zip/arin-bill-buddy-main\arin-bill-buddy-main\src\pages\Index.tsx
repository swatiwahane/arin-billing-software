import BillGenerator from './BillGenerator';

const Index = () => {
  return <BillGenerator />;
};

export default Index;
