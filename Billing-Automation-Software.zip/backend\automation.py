import time
import os
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

import shutil
from processing import extract_data_from_pdf, collection

class BillAutomation:
    def __init__(self, download_dir="downloads", port=9222):
        self.driver = None
        self.download_dir = os.path.abspath(download_dir)
        self.port = port
        self.process_date = None # Store the date for folder creation
        if not os.path.exists(self.download_dir):
            os.makedirs(self.download_dir)
        
        self.url = "https://wss.mahadiscom.in/wss/wss?uiActionName=getCustAccountLogin"

    def launch_browser(self):
        """Launches the Chrome browser."""
        try:
            options = webdriver.ChromeOptions()
            
            # minimal prefs for download
            prefs = {
                "download.default_directory": self.download_dir,
                "download.prompt_for_download": False,
                "download.directory_upgrade": True,
                "plugins.always_open_pdf_externally": True
            }
            options.add_experimental_option("prefs", prefs)
            options.add_argument("--start-maximized")
            
            # Minimal crucial args
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            options.add_argument(f"--remote-debugging-port={self.port}") # Helpful for debugging

            # Initialize driver
            logger.info(f"Initializing Chrome Driver on port {self.port} with download dir: {self.download_dir}")
            self.driver = webdriver.Chrome(options=options)
            
            # self.driver.maximize_window() # options handles this
            logger.info("Driver initialized. Navigating to URL...")
            
            try:
                self.driver.get(self.url)
                logger.info("Navigation complete.")
            except Exception as nav_e:
                logger.error(f"Navigation failed (timeout or network): {nav_e}")
                # We return True because the browser IS launched, even if the page didn't load perfectly.
                return True, f"Browser launched but navigation warning: {nav_e}"

            logger.info("Browser launched successfully.")
            return True, "Browser launched successfully."
            
        except Exception as e:
            logger.error(f"Error launching browser: {e}")
            # Write to a file for user visibility
            try:
                with open("launch_error.txt", "w") as f:
                    f.write(str(e))
            except:
                pass
            return False, str(e)
        except Exception as e:
            logger.error(f"Error launching browser: {e}")
            return False, str(e)

    def fill_login_credentials(self, date_str):
        """Generates credentials based on date and fills the login form."""
        if not self.driver:
            return False, "Browser not running."

        try:
            # Store date for download step
            self.process_date = date_str
            
            # Parse date string (handling ISO format from frontend)
            # Frontend sends UTC (toISOString), so we need to adjust for local time (IST)
            # or simply add enough hours to push it back to the correct date if it's a boundary issue.
            from datetime import datetime, timedelta
            
            if "T" in date_str:
                dt_obj = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
                # Add 5 hours 30 minutes for IST (since Mahadiscom is in India)
                # or just add 12 hours to be safe against midnight shifts in either direction if we assume date-only intent
                dt_obj = dt_obj + timedelta(hours=5, minutes=30)
            else:
                dt_obj = datetime.strptime(date_str, "%Y-%m-%d")
            
            day_num = dt_obj.day
            
            # Generate credential: e.g., Arin$007 for day 7
            credential = f"Arin${day_num:03d}"
            logger.info(f"Generated credential: {credential} for date {date_str}")
            
            # Wait for elements
            wait = WebDriverWait(self.driver, 10)
            login_input = wait.until(EC.presence_of_element_located((By.ID, "loginId")))
            password_input = wait.until(EC.presence_of_element_located((By.ID, "password")))
            
            # Clear and fill
            login_input.clear()
            login_input.send_keys(credential)
            
            password_input.clear()
            password_input.send_keys(credential)
            
            # Click Submit button
            try:
                # Common IDs for Mahadiscom login button
                submit_btn = self.driver.find_element(By.ID, "Submit")
                submit_btn.click()
                logger.info("Login form submitted.")
            except:
                try:
                    # Fallback to finding by type if ID fails
                    submit_btn = self.driver.find_element(By.XPATH, "//input[@type='submit']")
                    submit_btn.click()
                    logger.info("Login form submitted via fallback.")
                except Exception as e:
                    logger.warning(f"Could not click submit button: {e}")

            # Verification: Wait to see if we reached the dashboard
            try:
                wait = WebDriverWait(self.driver, 15)
                wait.until(EC.presence_of_element_located((By.ID, "grdCustList")))
                logger.info("Login verified: reached dashboard.")
                return True, f"Login successful for {credential}"
            except:
                logger.warning("Could not verify login. Might be stuck on CAPTCHA or invalid credentials.")
                return True, "Credentials filled, awaiting manual login/verification."
            
        except Exception as e:
            logger.error(f"Error filling credentials: {e}")
            return False, str(e)

    def get_consumer_list(self):
        """Scrapes the consumer data from the website by navigating to each bill page."""
        if not self.driver:
            return False, "Browser not running."
        
        try:
            consumers = []
            wait = WebDriverWait(self.driver, 10)
            
            # Find all View Bill buttons
            buttons = self.driver.find_elements(By.XPATH, "//img[@title='View Bill']")
            count = len(buttons)
            logger.info(f"Found {count} bills to fetch consumer info from.")
            
            for i in range(count):
                try:
                    # Re-find buttons (stale element reference prevention)
                    buttons = self.driver.find_elements(By.XPATH, "//img[@title='View Bill']")
                    if i >= len(buttons):
                        break
                    
                    btn = buttons[i]
                    btn.click()
                    
                    # Wait for detail page to load
                    time.sleep(2)
                    
                    # Extract consumer number and name from the detail page
                    try:
                        c_num_elem = wait.until(EC.presence_of_element_located((By.ID, "lblConsumerNumber")))
                        c_num = c_num_elem.text.strip()
                    except:
                        c_num = f"Unknown_{i}"
                        
                    try:
                        c_name_elem = self.driver.find_element(By.ID, "lblConsumerName")
                        c_name = c_name_elem.text.strip()
                    except:
                        c_name = "MSEDCL Consumer"
                    
                    logger.info(f"Fetched consumer {i+1}: {c_num} - {c_name}")
                    consumers.append({"consumerNumber": c_num, "name": c_name})
                    
                    # Navigate back to dashboard
                    self.driver.get("https://wss.mahadiscom.in/wss/wss?uiActionName=getMyAccount")
                    wait.until(EC.presence_of_element_located((By.ID, "grdCustList")))
                    time.sleep(1)
                    
                except Exception as iter_err:
                    logger.error(f"Error fetching consumer {i}: {iter_err}")
                    # Try to recover
                    try:
                        self.driver.get("https://wss.mahadiscom.in/wss/wss?uiActionName=getMyAccount")
                        time.sleep(2)
                    except:
                        pass
            
            logger.info(f"Scraped {len(consumers)} consumers with names.")
            return True, consumers
                
        except Exception as outer_err:
            logger.error(f"Error in get_consumer_list: {outer_err}")
            return False, str(outer_err)

    def download_bills(self, start_index=0, end_index=None):
        """Triggers the download of bills in a specific range."""
        if not self.driver:
            return False, "Browser not running."

        try:
            # 1. Prepare Download Directory
            date_str = self.process_date if self.process_date else "unknown_date"
            if "T" in date_str:
                date_str = date_str.split("T")[0]
                
            desktop_path = os.path.join(os.environ['USERPROFILE'], 'Desktop')
            target_dir = os.path.join(desktop_path, 'arin', date_str)
            if not os.path.exists(target_dir):
                os.makedirs(target_dir)
            logger.info(f"[{self.port}] Target download directory: {target_dir}")

            # Update Chrome preferences dynamically
            self.driver.execute_cdp_cmd("Page.setDownloadBehavior", {
                "behavior": "allow",
                "downloadPath": target_dir
            })

            wait = WebDriverWait(self.driver, 15)
            
            # Initial count
            potential_buttons = self.driver.find_elements(By.XPATH, "//img[@title='View Bill']")
            count = len(potential_buttons)
            
            if end_index is None:
                end_index = count
            
            # Limit end_index to total count
            real_end = min(end_index, count)
            logger.info(f"[{self.port}] Processing bills from index {start_index} to {real_end}.")
            
            downloaded = 0
            
            for i in range(start_index, real_end):
                try:
                    # Re-find elements because page reload invalidates them
                    buttons = self.driver.find_elements(By.XPATH, "//img[@title='View Bill']")
                    if i >= len(buttons):
                        break
                        
                    btn = buttons[i]
                    btn.click()
                    
                    # Wait for detail page load
                    try:
                        wait.until(EC.presence_of_element_located((By.ID, "lblConsumerNumber")))
                    except:
                        pass

                    # Inject JS to submit form for Printable View immediately
                    logger.info(f"[{self.port}] Injecting JS for bill {i+1}...")
                    js_code = """
                        var form = document.getElementById("HTEnergyBillForm");
                        if (form) {
                            form.target = '_self'; 
                            var consumerNumber = document.getElementById("lblConsumerNumber").innerHTML;
                            var billMonth = document.getElementById("lblBillMonth").innerHTML;
                            document.getElementById("hdnConsumerNumber").value = consumerNumber;
                            document.getElementById('uiActionName').value = "getHTEnergyBill";
                            document.getElementById('hdnBillMonth').value = billMonth;
                            form.submit();
                            return true;
                        } else {
                            return false;
                        }
                    """
                    
                    submitted = False
                    for attempt in range(5):
                        try:
                            result = self.driver.execute_script(js_code)
                            if result:
                                submitted = True
                                break
                            time.sleep(0.5)
                        except:
                            time.sleep(0.5)
                            
                    if not submitted:
                        logger.error(f"[{self.port}] Could not submit printable form.")
                        self.driver.back()
                        continue

                    # Wait for Printable View load
                    try:
                        wait.until(lambda d: d.execute_script('return document.readyState') == 'complete')
                    except:
                        pass
                        
                    time.sleep(2) 

                    # CDP Print
                    try:
                        pdf_data = self.driver.execute_cdp_cmd("Page.printToPDF", {
                            "printBackground": True,
                            "landscape": False,
                            "paperWidth": 8.27, 
                            "paperHeight": 11.69,
                            "marginTop": 0,
                            "marginBottom": 0,
                            "marginLeft": 0,
                            "marginRight": 0
                        })
                        
                        import base64
                        pdf_bytes = base64.b64decode(pdf_data['data'])
                        
                        # Try to get consumer number for filename
                        try:
                            c_num = self.driver.execute_script("return document.getElementById('lblConsumerNumber').innerHTML;")
                        except:
                            c_num = f"Unknown_{i+1}"
                            
                        pdf_filename = f"{c_num}_{date_str}.pdf"
                        pdf_path = os.path.join(target_dir, pdf_filename)
                        
                        with open(pdf_path, "wb") as f:
                            f.write(pdf_bytes)
                            
                        logger.info(f"[{self.port}] Saved: {pdf_filename}")
                        downloaded += 1

                        # REAL-TIME UPDATE: Extract and save to DB immediately
                        try:
                            extracted = extract_data_from_pdf(pdf_path)
                            if extracted and collection is not None:
                                collection.update_one({"filename": pdf_filename}, {"$set": extracted}, upsert=True)
                                logger.info(f"[{self.port}] Real-time DB Update for: {pdf_filename}")
                        except Exception as db_err:
                            logger.error(f"[{self.port}] Real-time DB sync failed: {db_err}")
                            
                    except Exception as cdp_err:
                        logger.error(f"[{self.port}] CDP Print failed: {cdp_err}")

                    # Navigate back
                    self.driver.get("https://wss.mahadiscom.in/wss/wss?uiActionName=getMyAccount")
                    wait.until(EC.presence_of_element_located((By.ID, "grdCustList")))
                    
                except Exception as iter_err:
                    logger.error(f"[{self.port}] Error processing bill {i}: {iter_err}")
                    try:
                        self.driver.get("https://wss.mahadiscom.in/wss/wss?uiActionName=getMyAccount")
                        wait.until(EC.presence_of_element_located((By.ID, "grdCustList")))
                    except:
                        pass
                        
            return True, f"[{self.port}] Downloaded {downloaded} files."

        except Exception as e:
            logger.error(f"[{self.port}] Error downloading bills: {e}")
            return False, str(e)

    def dump_html(self):
        """Dumps the current page HTML to a file for debugging."""
        if self.driver:
            try:
                with open(f"page_dump_{self.port}.html", "w", encoding="utf-8") as f:
                    f.write(self.driver.page_source)
                return True, "HTML dumped successfully."
            except Exception as e:
                return False, str(e)
        return False, "Browser not running."

    def close(self):
        if self.driver:
            try:
                self.driver.quit()
            except:
                pass
            self.driver = None
