import { useState, useRef, useCallback } from 'react';
import { Sidebar } from '@/components/Sidebar';
import { GenerationControls } from '@/components/GenerationControls';
import { BillPreview } from '@/components/BillPreview';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  ConsumerData,
  BillInputs,
  CalculatedBillData,
  calculateBillData,
} from '@/lib/billCalculations';
import { toast } from '@/hooks/use-toast';
import html2canvas from 'html2canvas';

export default function BillGenerator() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedConsumer, setSelectedConsumer] = useState<ConsumerData | null>(null);
  const [billData, setBillData] = useState<CalculatedBillData | null>(null);
  const billPreviewRef = useRef<HTMLDivElement>(null);

  const handleGenerate = useCallback((consumer: ConsumerData, inputs: BillInputs) => {
    const calculated = calculateBillData(inputs, consumer);
    setSelectedConsumer(consumer);
    setBillData(calculated);
    toast({
      title: "Bill Generated",
      description: `Preview generated for ${consumer.name}`,
    });
  }, []);

  const handleDownloadImage = useCallback(async () => {
    if (!billPreviewRef.current || !selectedConsumer) {
      toast({
        title: "Error",
        description: "Please generate a bill preview first",
        variant: "destructive",
      });
      return;
    }

    try {
      const canvas = await html2canvas(billPreviewRef.current, {
        scale: 2,
        backgroundColor: '#ffffff',
      });
      
      const link = document.createElement('a');
      link.download = `bill-${selectedConsumer.consumerNumber}-${selectedDate.getMonth() + 1}-${selectedDate.getFullYear()}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();

      toast({
        title: "Downloaded",
        description: "Bill image has been downloaded",
      });
    } catch {
      toast({
        title: "Error",
        description: "Failed to download image",
        variant: "destructive",
      });
    }
  }, [selectedConsumer, selectedDate]);

  const handleDownloadAllImages = useCallback(() => {
    toast({
      title: "Feature Coming Soon",
      description: "Bulk download will be available when connected to MongoDB",
    });
  }, []);

  return (
    <div className="flex min-h-screen w-full bg-background">
      <Sidebar />
      
      <main className="flex-1 p-6 lg:p-8 overflow-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">Bill Generator</h1>
          <p className="text-muted-foreground">
            Create and export solar journey bills for consumers
          </p>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column - Controls */}
          <GenerationControls
            onGenerate={handleGenerate}
            onDownloadImage={handleDownloadImage}
            onDownloadAllImages={handleDownloadAllImages}
            selectedDate={selectedDate}
            onDateChange={setSelectedDate}
          />

          {/* Right Column - Preview */}
          <Card className="h-fit">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg font-semibold">Live Preview</CardTitle>
            </CardHeader>
            <CardContent className="overflow-auto">
              <div className="bg-gradient-to-br from-teal-50 to-emerald-50 p-4 rounded-lg">
                <BillPreview
                  ref={billPreviewRef}
                  consumer={selectedConsumer}
                  billData={billData}
                  selectedDate={selectedDate}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
