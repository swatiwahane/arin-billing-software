import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { CalendarIcon, Eye, Download, FolderDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { ConsumerData, BillInputs, mockConsumers } from '@/lib/billCalculations';

interface GenerationControlsProps {
  onGenerate: (consumer: ConsumerData, inputs: BillInputs) => void;
  onDownloadImage: () => void;
  onDownloadAllImages: () => void;
  selectedDate: Date;
  onDateChange: (date: Date) => void;
}

export function GenerationControls({
  onGenerate,
  onDownloadImage,
  onDownloadAllImages,
  selectedDate,
  onDateChange,
}: GenerationControlsProps) {
  const [selectedConsumerId, setSelectedConsumerId] = useState<string>('');
  const [inputs, setInputs] = useState<BillInputs>({
    readingDate: selectedDate,
    generatedElectricity: 172,
    exportedToGrid: 137,
    importedFromGrid: 64,
    billingAmount: 140,
    previousBankedUnit: 493,
    currentBankedUnit: 566,
    systemHealth: 'POOR',
    billStatus: 'Normal',
  });

  useEffect(() => {
    setInputs(prev => ({ ...prev, readingDate: selectedDate }));
  }, [selectedDate]);

  const selectedConsumer = mockConsumers.find(c => c.id === selectedConsumerId);

  const handleInputChange = (field: keyof BillInputs, value: number | string) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  const handleGenerate = () => {
    if (selectedConsumer) {
      onGenerate(selectedConsumer, inputs);
    }
  };

  return (
    <Card className="h-full">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-semibold">Generation Controls</CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* Date Picker */}
        <div className="space-y-2">
          <Label>Select Reading Date</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  'w-full justify-start text-left font-normal',
                  !selectedDate && 'text-muted-foreground'
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {selectedDate ? format(selectedDate, 'dd/MM/yyyy') : 'Pick a date'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={(date) => date && onDateChange(date)}
                initialFocus
                className="p-3 pointer-events-auto"
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Consumer Select */}
        <div className="space-y-2">
          <Label>Select Consumer Number</Label>
          <Select value={selectedConsumerId} onValueChange={setSelectedConsumerId}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Search consumer..." />
            </SelectTrigger>
            <SelectContent>
              {mockConsumers.map((consumer) => (
                <SelectItem key={consumer.id} value={consumer.id}>
                  {consumer.consumerNumber} - {consumer.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Input Fields Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-xs">Generated (kWh)</Label>
            <Input
              type="number"
              value={inputs.generatedElectricity}
              onChange={(e) => handleInputChange('generatedElectricity', Number(e.target.value))}
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Exported (kWh)</Label>
            <Input
              type="number"
              value={inputs.exportedToGrid}
              onChange={(e) => handleInputChange('exportedToGrid', Number(e.target.value))}
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Imported (kWh)</Label>
            <Input
              type="number"
              value={inputs.importedFromGrid}
              onChange={(e) => handleInputChange('importedFromGrid', Number(e.target.value))}
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Billing Amount</Label>
            <Input
              type="number"
              value={inputs.billingAmount}
              onChange={(e) => handleInputChange('billingAmount', Number(e.target.value))}
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Prev Banked</Label>
            <Input
              type="number"
              value={inputs.previousBankedUnit}
              onChange={(e) => handleInputChange('previousBankedUnit', Number(e.target.value))}
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">Current Banked</Label>
            <Input
              type="number"
              value={inputs.currentBankedUnit}
              onChange={(e) => handleInputChange('currentBankedUnit', Number(e.target.value))}
            />
          </div>
        </div>

        {/* System Health Select */}
        <div className="space-y-2">
          <Label>System Health</Label>
          <Select
            value={inputs.systemHealth}
            onValueChange={(value: 'Normal' | 'POOR') => handleInputChange('systemHealth', value)}
          >
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Normal">Normal</SelectItem>
              <SelectItem value="POOR">POOR</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 pt-2">
          <Button
            onClick={handleGenerate}
            disabled={!selectedConsumer}
            className="w-full bg-primary hover:bg-primary/90"
          >
            <Eye className="mr-2 h-4 w-4" />
            Generate Bill Preview
          </Button>
          <Button
            variant="outline"
            onClick={onDownloadImage}
            className="w-full"
          >
            <Download className="mr-2 h-4 w-4" />
            Download Image
          </Button>
          <Button
            variant="outline"
            onClick={onDownloadAllImages}
            className="w-full"
          >
            <FolderDown className="mr-2 h-4 w-4" />
            Download All Images for Month
          </Button>
        </div>

        {/* Bill Summary */}
        {selectedConsumer && (
          <div className="pt-4 border-t space-y-2">
            <h4 className="font-medium text-sm">Bill Summary</h4>
            <div className="text-sm space-y-1">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Consumer:</span>
                <span className="font-medium">{selectedConsumer.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Period:</span>
                <span className="font-medium">{format(selectedDate, 'MMMM yyyy')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Net Units:</span>
                <span className="font-medium text-arin-green">
                  {inputs.generatedElectricity - inputs.exportedToGrid - inputs.importedFromGrid > 0 ? '+' : ''}
                  {inputs.generatedElectricity - inputs.exportedToGrid - inputs.importedFromGrid} kWh
                </span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
