import { forwardRef } from 'react';
import { ConsumerData, CalculatedBillData, getMonthYear } from '@/lib/billCalculations';
import { Sun } from 'lucide-react';

interface BillPreviewProps {
  consumer: ConsumerData | null;
  billData: CalculatedBillData | null;
  selectedDate: Date;
}

export const BillPreview = forwardRef<HTMLDivElement, BillPreviewProps>(
  ({ consumer, billData, selectedDate }, ref) => {
    if (!consumer || !billData) {
      return (
        <div className="bg-white border border-gray-200 rounded-lg p-8 min-h-[600px] flex items-center justify-center">
          <div className="text-center text-muted-foreground">
            <Sun className="w-16 h-16 mx-auto mb-4 opacity-20" />
            <p>Select a consumer and generate bill to preview</p>
          </div>
        </div>
      );
    }

    const monthYear = getMonthYear(selectedDate);

    return (
      <div ref={ref} className="bg-white border border-gray-300 p-4 font-condensed text-sm" id="bill-preview">
        {/* Header */}
        <div className="text-center mb-3">
          <h1 className="text-xl font-bold bill-header-title">
            <span className="text-arin-red">Your </span>
            <span className="text-arin-green text-2xl">Solar Journey</span>
            <span className="text-arin-red"> with </span>
            <span className="text-arin-green text-2xl">Arin Energy</span>
            <span className="text-arin-red"> of </span>
            <span className="text-arin-green text-2xl">{monthYear}</span>
          </h1>
        </div>

        {/* Consumer Info Header */}
        <div className="flex justify-between items-start mb-2 border-b border-gray-300 pb-2">
          <div className="space-y-1">
            <div className="flex gap-2">
              <span className="font-medium">Consumer Name :</span>
              <span className="uppercase">{consumer.name}</span>
            </div>
            <div className="flex gap-2">
              <span className="font-medium">Capacity:</span>
              <span>{consumer.capacity}</span>
            </div>
          </div>
          <div className="text-right">
            <div className="flex items-center gap-2">
              <span className="text-arin-green font-bold text-lg">ar</span>
              <span className="text-arin-red font-bold text-lg">i</span>
              <span className="text-arin-green font-bold text-lg">n</span>
            </div>
            <div className="text-[10px] text-gray-600">
              <span className="text-arin-red">E</span>
              <span>NERGY</span>
            </div>
            <div className="text-[8px] text-gray-500 italic">Harnessing Sunshine!</div>
          </div>
        </div>

        {/* Main Data Table */}
        <table className="bill-table mb-3">
          <thead>
            <tr>
              <th className="w-3/5">Parameter</th>
              <th className="w-2/5 text-right">Units(kWh) /Amount</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="font-medium">Reading Date</td>
              <td className="text-right">{billData.readingDate}</td>
            </tr>
            <tr>
              <td className="font-medium">Generated Electricity</td>
              <td className="text-right">{billData.generatedElectricity}</td>
            </tr>
            <tr>
              <td className="font-medium">Exported to Grid</td>
              <td className="text-right">{billData.exportedToGrid}</td>
            </tr>
            <tr>
              <td className="font-medium">Imported from Grid</td>
              <td className="text-right">{billData.importedFromGrid}</td>
            </tr>
            <tr>
              <td className="font-medium text-arin-green">
                Daytime Self Consumption = Generated - Exported
              </td>
              <td className="text-right">{billData.daytimeSelfConsumption}</td>
            </tr>
            <tr>
              <td className="font-medium text-arin-green">
                Total Consumption = Self consumption + Imported
              </td>
              <td className="text-right">{billData.totalConsumption}</td>
            </tr>
            <tr>
              <td className="font-medium text-arin-green">
                Billing Units = Total Consumation - Generated
              </td>
              <td className="text-right">{billData.billingUnits}</td>
            </tr>
            <tr>
              <td className="font-medium">Billing Amount</td>
              <td className="text-right">{billData.billingAmount}</td>
            </tr>
            <tr>
              <td className="font-medium">Previous Banked unit</td>
              <td className="text-right">{billData.previousBankedUnit}</td>
            </tr>
            <tr>
              <td className="font-medium">Current Banked Unit</td>
              <td className="text-right">{billData.currentBankedUnit}</td>
            </tr>
            <tr>
              <td className="font-medium">System Health</td>
              <td className={`text-right font-bold ${
                billData.systemHealth === 'POOR' 
                  ? 'bg-red-500 text-black' 
                  : ''
              }`}>
                {billData.systemHealth}
              </td>
            </tr>
            <tr>
              <td className="font-medium">Bill Status</td>
              <td className="text-right">{billData.billStatus}</td>
            </tr>
          </tbody>
        </table>

        {/* Warranty Section */}
        <table className="bill-table mb-2">
          <tbody>
            <tr>
              <td className="font-bold bg-yellow-100 w-1/4">Panel Warranty:</td>
              <td className="w-1/4">{consumer.panelWarranty}</td>
              <td className="font-bold bg-yellow-100 w-1/4">Inverter Warranty:</td>
              <td className="w-1/4">{consumer.inverterWarranty}</td>
            </tr>
            <tr>
              <td className="font-bold bg-yellow-100">System Warranty:</td>
              <td>{consumer.systemWarranty}</td>
              <td></td>
              <td></td>
            </tr>
          </tbody>
        </table>

        {/* Footer Tagline */}
        <div className="bg-yellow-400 text-center py-2 font-bold text-lg mb-1">
          <span className="text-arin-green">Your personal power plant working for you since</span>
          <span className="text-black mx-4 text-2xl">{billData.daysSinceInstallation}</span>
          <span className="text-arin-green">Days!</span>
        </div>

        {/* Helpline */}
        <div className="bg-yellow-400 text-center py-1 text-sm">
          <span className="text-arin-red font-medium">
            Facing an Issue? Let's Solve It Together – Call Us{' '}
          </span>
          <span className="text-black font-bold">+91 7620101758</span>
        </div>
      </div>
    );
  }
);

BillPreview.displayName = 'BillPreview';
