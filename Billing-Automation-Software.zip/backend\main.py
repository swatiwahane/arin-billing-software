from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import logging
import os
import glob
from concurrent.futures import ThreadPoolExecutor
from automation import BillAutomation
from processing import process_downloads, get_all_bills, get_dashboard_stats

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="BillBot API")

# Allow CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global instances
primary_automation = BillAutomation(port=9222)
executor = ThreadPoolExecutor(max_workers=5)
global_total_bills = 0

class LaunchRequest(BaseModel):
    date: str

class DownloadRequest(BaseModel):
    workers: int = 1

@app.get("/")
def read_root():
    return {"status": "BillBot Backend is running"}

@app.post("/api/launch")
def launch_automation(request: LaunchRequest):
    """Launches the primary browser and navigates to the portal."""
    success, message = primary_automation.launch_browser()
    if not success:
        raise HTTPException(status_code=500, detail=message)
    
    primary_automation.fill_login_credentials(request.date)
    return {"status": "success", "message": message}

@app.get("/api/consumers")
def fetch_consumers():
    """Scrapes the consumer list from the primary browser session."""
    success, data = primary_automation.get_consumer_list()
    if not success:
        raise HTTPException(status_code=500, detail=data)
    return data

@app.get("/api/stats")
def get_stats():
    """Returns dashboard statistics from MongoDB."""
    return get_dashboard_stats()

def worker_task(worker_index, date, start_idx, end_idx):
    """Logic for a single parallel worker instance."""
    port = 9223 + worker_index
    logger.info(f"Worker {worker_index} starting on port {port} for range {start_idx}-{end_idx}")
    
    worker = BillAutomation(port=port)
    try:
        worker.launch_browser()
        worker.fill_login_credentials(date)
        
        # Click login (we'll ensure automation.py handles the click, but we can also do it here)
        # Wait for page to settle after login
        import time
        time.sleep(5) 
        
        # Explicitly navigate to the account list page to be safe
        worker.driver.get("https://wss.mahadiscom.in/wss/wss?uiActionName=getMyAccount")
        time.sleep(3)
        
        worker.download_bills(start_index=start_idx, end_index=end_idx)
    except Exception as e:
        logger.error(f"Worker {worker_index} failed: {e}")
    finally:
        worker.close()

@app.post("/api/download")
def start_download(request: DownloadRequest, background_tasks: BackgroundTasks):
    global global_total_bills
    """Triggers the download process with parallel workers."""
    if not primary_automation.driver:
        raise HTTPException(status_code=400, detail="Primary browser not active. Please launch and login first.")
    
    # Get total count first from primary
    from selenium.webdriver.common.by import By
    try:
        buttons = primary_automation.driver.find_elements(By.XPATH, "//img[@title='View Bill']")
        total_count = len(buttons)
    except Exception as e:
        logger.error(f"Error finding buttons: {e}")
        total_count = 0
    
    if total_count == 0:
        return {"status": "warning", "message": "No bills found to download. Please ensure you are on the list page."}

    global_total_bills = total_count
    # Decide how many workers to use
    num_workers = min(request.workers, total_count, 5)
    logger.info(f"Splitting {total_count} bills among {num_workers} workers.")
    
    # Calculate chunks
    chunk_size = (total_count + num_workers - 1) // num_workers
    date = primary_automation.process_date
    
    # Dispatch primary chunk
    primary_end = min(chunk_size, total_count)
    if primary_end > 0:
        background_tasks.add_task(primary_automation.download_bills, 0, primary_end)
        logger.info(f"Primary worker (Active Browser) handling range 0 to {primary_end}")

    # Dispatch other workers
    for i in range(1, num_workers):
        start = i * chunk_size
        end = min(start + chunk_size, total_count)
        if start < total_count:
            background_tasks.add_task(worker_task, i, date, start, end)
            logger.info(f"Dispatched worker {i} for range {start} to {end}")
            
    return {
        "status": "success", 
        "message": f"Assigned {total_count} bills to {num_workers} workers.",
        "details": f"Primary: 0-{primary_end}, Others: {num_workers-1} instances started."
    }

@app.post("/api/process")
def process_data():
    """Triggers PDF processing and MongoDB storage."""
    date_str = primary_automation.process_date if primary_automation.process_date else "unknown_date"
    if "T" in date_str:
        date_str = date_str.split("T")[0]
        
    storage_path = os.path.join(os.path.join(os.environ.get('USERPROFILE', 'C:\\Users\\Manasi'), 'Desktop'), 'arin', date_str)
    
    count = process_downloads(storage_path)
    return {"status": "success", "processed_count": count}

@app.get("/api/bills")
def get_bills():
    """Returns the final processed data from MongoDB."""
    return get_all_bills()

@app.get("/api/download-status")
def get_download_status():
    """Returns current download status."""
    date_str = primary_automation.process_date if primary_automation.process_date else "unknown_date"
    if "T" in date_str:
        date_str = date_str.split("T")[0]
        
    storage_path = os.path.join(os.path.join(os.environ.get('USERPROFILE', 'C:\\Users\\Manasi'), 'Desktop'), 'arin', date_str)
    
    # Get total count
    total_bills = global_total_bills
    if total_bills == 0:
        try:
            if primary_automation.driver:
                from selenium.webdriver.common.by import By
                buttons = primary_automation.driver.find_elements(By.XPATH, "//img[@title='View Bill']")
                total_bills = len(buttons)
        except:
            pass
    
    # Get downloaded files
    downloaded_files = []
    if os.path.exists(storage_path):
        pdf_files = glob.glob(os.path.join(storage_path, "*.pdf"))
        for pdf in pdf_files:
            filename = os.path.basename(pdf)
            mtime = os.path.getmtime(pdf)
            downloaded_files.append({
                "filename": filename,
                "timestamp": mtime
            })
        downloaded_files.sort(key=lambda x: x["timestamp"], reverse=True)
    
    return {
        "storagePath": storage_path,
        "totalBills": total_bills,
        "downloadedCount": len(downloaded_files),
        "files": downloaded_files
    }
