import { FileText, Sun } from 'lucide-react';

export function Sidebar() {
  return (
    <aside className="w-64 min-h-screen bg-sidebar flex flex-col">
      {/* Logo Header */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-arin-teal flex items-center justify-center">
            <Sun className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-white font-semibold text-lg">Arin Energy</h1>
            <p className="text-sidebar-foreground text-xs opacity-70">Billing Portal</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <button className="sidebar-nav-item w-full text-left active">
          <FileText className="w-5 h-5" />
          <span className="flex-1">Bill Generator</span>
        </button>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border">
        <p className="text-sidebar-foreground text-xs opacity-50 text-center">
          Harnessing Sunshine!
        </p>
      </div>
    </aside>
  );
}
